import React from "react";

function MainPage() {
  return (
    <div className="text-center mt-10">
      <h2 className="text-2xl font-bold mb-4">Главная страница</h2>
      <p className="text-gray-700">Добро пожаловать в СмарТ Меню!</p>
    </div>
  );
}

export default MainPage;
